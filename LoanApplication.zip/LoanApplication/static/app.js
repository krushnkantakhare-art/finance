const form = document.querySelector("#loan-form");
const result = document.querySelector("#result");
const submitButton = form.querySelector('button[type="submit"]');

function showResult(title, detail, isError = false) {
  result.replaceChildren();
  result.classList.toggle("error", isError);

  const heading = document.createElement("p");
  heading.className = "result-title";
  heading.textContent = title;
  const message = document.createElement("p");
  message.className = "result-detail";
  message.textContent = detail;

  result.append(heading, message);
  result.hidden = false;
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (!form.reportValidity()) return;

  const values = Object.fromEntries(new FormData(form).entries());
  for (const field of [
    "ApplicantIncome",
    "CoapplicantIncome",
    "LoanAmount",
    "Loan_Amount_Term",
  ]) {
    values[field] = Number(values[field]);
  }

  submitButton.disabled = true;
  submitButton.querySelector("span").textContent = "Calculating estimate…";
  result.hidden = true;

  try {
    const response = await fetch("/predict", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(values),
    });
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error || "Unable to predict loan status.");

    const confidence = Number.isFinite(payload.confidence)
      ? ` Model confidence: ${Math.round(payload.confidence * 100)}%.`
      : "";
    const detail = payload.reason || `This result is an estimate only.${confidence}`;
    showResult(`Estimated status: ${payload.prediction}`, detail);
  } catch (error) {
    showResult("We couldn't complete the estimate.", error.message, true);
  } finally {
    submitButton.disabled = false;
    submitButton.querySelector("span").textContent = "Predict loan status";
  }
});
