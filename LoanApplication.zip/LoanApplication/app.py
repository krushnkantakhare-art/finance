from __future__ import annotations

import logging
import math
from pathlib import Path
from typing import Any

import joblib
import pandas as pd
from flask import Flask, jsonify, render_template, request


BASE_DIR = Path(__file__).resolve().parent
MODEL_PATH = BASE_DIR / "loan_model.pkl"
FEATURES = [
    "Gender",
    "Married",
    "Dependents",
    "Education",
    "Self_Employed",
    "ApplicantIncome",
    "CoapplicantIncome",
    "LoanAmount",
    "Loan_Amount_Term",
    "Credit_History",
    "Property_Area",
]
CATEGORICAL_OPTIONS = {
    "Gender": {"Male", "Female"},
    "Married": {"Yes", "No"},
    "Dependents": {"0", "1", "2", "3+"},
    "Education": {"Graduate", "Not Graduate"},
    "Self_Employed": {"Yes", "No"},
    "Property_Area": {"Urban", "Semiurban", "Rural"},
}

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
app = Flask(__name__)

if not MODEL_PATH.is_file():
    raise FileNotFoundError(
        f"Loan model not found at {MODEL_PATH}. Place loan_model.pkl beside app.py."
    )

try:
    model = joblib.load(MODEL_PATH)
except Exception:
    logger.exception("Could not load the loan prediction model from %s", MODEL_PATH)
    raise


def parse_input(data: dict[str, Any]) -> dict[str, Any]:
    """Validate and convert the submitted fields to the model's input types."""
    values: dict[str, Any] = {}
    for feature, options in CATEGORICAL_OPTIONS.items():
        value = data.get(feature)
        if not isinstance(value, str) or value not in options:
            raise ValueError(f"Select a valid value for {feature.replace('_', ' ')}.")
        values[feature] = value

    numeric_fields = {
        "ApplicantIncome": "Applicant income",
        "CoapplicantIncome": "Co-applicant income",
        "LoanAmount": "Loan amount",
        "Loan_Amount_Term": "Loan term",
    }
    for feature, label in numeric_fields.items():
        raw_value = data.get(feature)
        try:
            value = float(raw_value)
        except (TypeError, ValueError):
            raise ValueError(f"Enter a valid {label.lower()}.") from None
        if not math.isfinite(value) or value < 0:
            raise ValueError(f"{label} must be a non-negative number.")
        if feature in {"ApplicantIncome", "CoapplicantIncome", "Loan_Amount_Term"}:
            if not value.is_integer():
                raise ValueError(f"{label} must be a whole number.")
            value = int(value)
        values[feature] = value

    raw_credit_history = data.get("Credit_History")
    if raw_credit_history is None:
        values["Credit_History"] = float("nan")
    else:
        try:
            credit_history = float(raw_credit_history)
        except (TypeError, ValueError):
            raise ValueError("Enter a valid credit history.") from None
        if not math.isfinite(credit_history) or credit_history not in {0, 1}:
            raise ValueError("Credit history must be 0 or 1.")
        values["Credit_History"] = credit_history

    return values


def format_prediction(label: Any) -> str:
    """Translate common binary loan-status labels into readable text."""
    normalized = str(label).strip().lower()
    if normalized in {"y", "1", "true", "approved", "loan approved"}:
        return "Approved"
    if normalized in {"n", "0", "false", "rejected", "not approved"}:
        return "Not approved"
    return str(label)


@app.get("/")
def index():
    return render_template("index.html")


@app.post("/predict")
def predict():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return jsonify({"error": "Submit the loan details as JSON."}), 400

    try:
        values = parse_input(data)
    except ValueError as error:
        return jsonify({"error": str(error)}), 400

    if values["ApplicantIncome"] == 0:
        return jsonify({
            "prediction": "Not approved",
            "reason": "Applicant income must be greater than zero for approval.",
        })

    try:
        input_frame = pd.DataFrame([values], columns=FEATURES)
        prediction = model.predict(input_frame)[0]
        response: dict[str, Any] = {
            "prediction": format_prediction(prediction),
            "label": str(prediction),
        }
        if hasattr(model, "predict_proba"):
            probabilities = model.predict_proba(input_frame)[0]
            classes = list(getattr(model, "classes_", []))
            class_index = next(
                (index for index, value in enumerate(classes) if value == prediction),
                None,
            )
            if class_index is not None:
                response["confidence"] = round(float(probabilities[class_index]), 4)
        return jsonify(response)
    except Exception:
        logger.exception("Loan prediction failed")
        return jsonify({"error": "The model could not generate a prediction."}), 500


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
