# applicationloan

Loan application eligibility prediction web app.

## Run locally

Install the dependencies:

```powershell
pip install -r requirements.txt
```

Start the app:

```powershell
python app.py
```

Then open http://127.0.0.1:5000/ in your browser.
